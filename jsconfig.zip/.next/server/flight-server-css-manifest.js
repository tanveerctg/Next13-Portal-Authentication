self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "D:\\next-js-portal-authentication\\app\\layout.js": [
      "D:\\next-js-portal-authentication\\app\\globals.css",
      "D:\\next-js-portal-authentication\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  },
  "cssModules": {
    "D:\\next-js-portal-authentication\\app\\reset_password\\page": [
      "D:\\next-js-portal-authentication\\app\\globals.css",
      "D:\\next-js-portal-authentication\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ],
    "D:\\next-js-portal-authentication\\app\\[...not_found]\\page": [
      "D:\\next-js-portal-authentication\\app\\globals.css",
      "D:\\next-js-portal-authentication\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  }
}