self.__RSC_MANIFEST={
  "ssrModuleMapping": {
    "(app-client)/./node_modules/next/dist/client/components/app-router.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "getServerActionDispatcher": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "getServerActionDispatcher",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "urlToUrlWithoutFlightMarker": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "urlToUrlWithoutFlightMarker",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/error-boundary.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "ErrorBoundaryHandler": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "ErrorBoundaryHandler",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "ErrorBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "ErrorBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "RedirectErrorBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "RedirectErrorBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "RedirectBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "RedirectBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/layout-router.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/link.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "*",
        "chunks": [
          "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "",
        "chunks": [
          "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "default",
        "chunks": [
          "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
        ],
        "async": false
      }
    },
    "(app-client)/./app/reset_password/page.js": {
      "*": {
        "id": "(sc_client)/./app/reset_password/page.js",
        "name": "*",
        "chunks": [
          "app/reset_password/page:static/chunks/app/reset_password/page.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./app/reset_password/page.js",
        "name": "",
        "chunks": [
          "app/reset_password/page:static/chunks/app/reset_password/page.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./app/reset_password/page.js",
        "name": "default",
        "chunks": [
          "app/reset_password/page:static/chunks/app/reset_password/page.js"
        ],
        "async": false
      }
    }
  },
  "edgeSSRModuleMapping": {},
  "cssFiles": {
    "D:\\next-js-portal-authentication\\app\\layout": [
      "static/css/app/layout.css"
    ]
  },
  "clientModules": {
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\app-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\app-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\app-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\app-router.js#getServerActionDispatcher": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "getServerActionDispatcher",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#getServerActionDispatcher": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "getServerActionDispatcher",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\app-router.js#urlToUrlWithoutFlightMarker": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "urlToUrlWithoutFlightMarker",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#urlToUrlWithoutFlightMarker": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "urlToUrlWithoutFlightMarker",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\error-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\error-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\error-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\error-boundary.js#ErrorBoundaryHandler": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundaryHandler",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#ErrorBoundaryHandler": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundaryHandler",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\error-boundary.js#ErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#ErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#RedirectErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#RedirectErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#RedirectBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#RedirectBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#CacheStates": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "CacheStates",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#CacheStates": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "CacheStates",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#AppRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "AppRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#AppRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "AppRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#LayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "LayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#LayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "LayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#GlobalLayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "GlobalLayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#GlobalLayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "GlobalLayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#TemplateContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "TemplateContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#TemplateContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "TemplateContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#SearchParamsContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "SearchParamsContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#SearchParamsContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "SearchParamsContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#PathnameContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "PathnameContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#PathnameContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "PathnameContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#ServerInsertedHTMLContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "ServerInsertedHTMLContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#ServerInsertedHTMLContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "ServerInsertedHTMLContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#useServerInsertedHTML": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "useServerInsertedHTML",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#useServerInsertedHTML": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "useServerInsertedHTML",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\layout-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\layout-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\layout-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\app\\globals.css#": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}#": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\link.js": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "*",
      "chunks": [
        "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\link.js": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "*",
      "chunks": [
        "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\link.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "",
      "chunks": [
        "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\link.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "",
      "chunks": [
        "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\client\\link.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "default",
      "chunks": [
        "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\node_modules\\next\\dist\\esm\\client\\link.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "default",
      "chunks": [
        "app/[...not_found]/page:static/chunks/app/[...not_found]/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\app\\reset_password\\page.js": {
      "id": "(app-client)/./app/reset_password/page.js",
      "name": "*",
      "chunks": [
        "app/reset_password/page:static/chunks/app/reset_password/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\app\\reset_password\\page.js#": {
      "id": "(app-client)/./app/reset_password/page.js",
      "name": "",
      "chunks": [
        "app/reset_password/page:static/chunks/app/reset_password/page.js"
      ],
      "async": false
    },
    "D:\\next-js-portal-authentication\\app\\reset_password\\page.js#default": {
      "id": "(app-client)/./app/reset_password/page.js",
      "name": "default",
      "chunks": [
        "app/reset_password/page:static/chunks/app/reset_password/page.js"
      ],
      "async": false
    }
  }
}