/** @type {import('next').NextConfig} */
const nextConfig = { skipMiddlewareUrlNormalize: true };

module.exports = nextConfig;
